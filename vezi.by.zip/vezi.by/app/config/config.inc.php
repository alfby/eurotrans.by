<?php
if (!defined("PJ_HOST")) define("PJ_HOST", "localhost");
if (!defined("PJ_USER")) define("PJ_USER", "veziby");
if (!defined("PJ_PASS")) define("PJ_PASS", "utupeneru");
if (!defined("PJ_DB")) define("PJ_DB", "zadmin_veziby");
if (!defined("PJ_PREFIX")) define("PJ_PREFIX", "");
if (!defined("PJ_INSTALL_FOLDER")) define("PJ_INSTALL_FOLDER", "/");
if (!defined("PJ_INSTALL_PATH")) define("PJ_INSTALL_PATH", "/var/zpanel/hostdata/zadmin/public_html/vezi_by/");
if (!defined("PJ_INSTALL_URL")) define("PJ_INSTALL_URL", "http://vezi.by/");
if (!defined("PJ_SALT")) define("PJ_SALT", "17EOE4BN");
if (!defined("PJ_INSTALLATION")) define("PJ_INSTALLATION", "MTIyOTM0Nzg3NzI2NjcwOTMzNTUxMjA3OTcwNzY3OTExOTA3NTUwMTEwMzA1ODY4OTQ1NzUyNTUxOTQ3MDE4MTM2ODc3NjA0OTI3OTc1ODUxNjI3NjEyNDM0OTMyOTExNjQ3NiAzNzE0Nzg1MTQ4ODM3MTA1NjM0NTMwOTcwNzUxODQwMzEzNzY5NDQ1Mzg5NjQ0NzI4OTgwNTIwOTY0MjI2OTY0OTk5ODI0MDM3NDUwNjY2MDE2MDc3NTY2OTYyMzA4Njg3ODQgMTMxNDcwMTkzNjM1MjMyNTE0MTU4MjMyNzY5MzgyOTY5NzgxODYzNjg5Mjg2MzY0MzIwNjc4NTQzNjY5MjE4Mjc3MDMwNjA3NDEwODkzOTY4MDM1MzA1NjE0NjE3MTU5MDU2Mg==");
?>