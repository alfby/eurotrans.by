<div id="return-journey-section">
    <strong><?__('front_return_journey');?></strong>
</div>