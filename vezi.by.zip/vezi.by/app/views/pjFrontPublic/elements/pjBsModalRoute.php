<div class="modal fade pjBsModal pjBsModalRoute" id="pjBsModalRoute" tabindex="-1" role="dialog" aria-labelledby="pjBsModalRouteLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <header class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <p class="modal-title"><?=__('front_destinations');?></p>
            </header>

            <div class="modal-body"></div>
        </div>
    </div>
</div>