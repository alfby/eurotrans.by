<ul class="list-inline pjBsSeatsKey">
    <li>
        <span class="pjBsSeat pjBsSeatAvailable"></span>
        <span><? __('front_available');?></span>
    </li>
    <li>
        <span class="pjBsSeat pjBsSeatSelected"></span>
        <span><? __('front_selected');?></span>
    </li>
    <li>
        <span class="pjBsSeat pjBsSeatBooked"></span>
        <span><? __('front_booked');?></span>
    </li>
</ul>