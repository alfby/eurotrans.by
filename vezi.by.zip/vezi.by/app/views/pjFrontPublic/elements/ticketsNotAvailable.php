<div class='tickets-not-available'>
    <?__('front_notavailable_tickets_from');?> <strong><?=$bus_list['from_location']?></strong> 
    <?__('front_tickets_to');?> <strong><?=$bus_list['to_location']?></strong> 
    <?__('front_tickets_not_available');?>.
</div>