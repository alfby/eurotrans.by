<header class="panel-heading pjBsSeatsHead">
    <div class="row">
        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-8">
            <p class="panel-title pjBsSeatsTitle"><?__('front_bus');?></p>
        </div>

        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-4">
            <p class="panel-title pjBsSeatsTitle"><?__('front_available_seats');?></p>
        </div>

        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 hidden-xs">
            <p class="panel-title pjBsSeatsTitle"><?__('front_departure_time');?></p>
        </div>

        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 hidden-xs">
            <p class="panel-title pjBsSeatsTitle"><?__('front_arrival_time');?></p>
        </div>

        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-4 hidden-xs">
                <p class="panel-title pjBsSeatsTitle"><?=__('front_duration');?></p>
        </div>
    </div>
</header>